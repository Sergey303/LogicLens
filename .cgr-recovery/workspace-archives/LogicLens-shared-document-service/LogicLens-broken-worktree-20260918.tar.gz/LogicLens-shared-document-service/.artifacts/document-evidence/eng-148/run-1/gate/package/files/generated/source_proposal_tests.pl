:- begin_tests(source_proposal_gate).
:- use_module('./source_proposal.pl').

test(reviewed_status_001) :- source_proposal:claim_status('owns_outcome'('role.product_owner', 'outcome.product_value'), supported).
test(open_world_unknown) :- source_proposal:claim_status('unknown_probe'('document-evidence-pdf-v1'), unknown).

:- end_tests(source_proposal_gate).
