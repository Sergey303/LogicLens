:- module(source_proposal, [source_assertion/6, claim_status/2, claim_evidence/3]).

% Generated only from source-grounding-reviewed assertions.
% Absence remains unknown and is never compiled as opposition.

source_assertion('document-evidence.po.product-value.support', 'owns_outcome'('role.product_owner', 'outcome.product_value'), 'support', 'document-evidence.pdf.product-owner', ['document-evidence-pdf#p-0001-b-0002'], 'context-dependent').

positive_evidence(Proposition, Id) :- source_assertion(Id, Proposition, support, _, _, _).
negative_evidence(Proposition, Id) :- source_assertion(Id, Proposition, oppose, _, _, _).

claim_status(Proposition, conflicting) :- positive_evidence(Proposition, _), negative_evidence(Proposition, _), !.
claim_status(Proposition, supported) :- positive_evidence(Proposition, _), \+ negative_evidence(Proposition, _), !.
claim_status(Proposition, refuted) :- negative_evidence(Proposition, _), \+ positive_evidence(Proposition, _), !.
claim_status(Proposition, unknown) :- \+ positive_evidence(Proposition, _), \+ negative_evidence(Proposition, _).

claim_evidence(Proposition, supported, Evidence) :- findall(Id, positive_evidence(Proposition, Id), Evidence).
claim_evidence(Proposition, refuted, Evidence) :- findall(Id, negative_evidence(Proposition, Id), Evidence).
claim_evidence(Proposition, conflicting, Evidence) :- findall(Id, source_assertion(Id, Proposition, _, _, _, _), Evidence).
claim_evidence(_, unknown, []).
