% fixture policy
