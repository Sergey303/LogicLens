#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import random

SEED = 20260801
SPLITS = ("train", "dev", "holdout", "replication")
STATUSES = ("supported", "refuted", "unknown", "conflicting")
QUESTION_TEMPLATES = {
    "train": (
        "Подтверждают ли источники, что ревизия {r} использует материал {m}?",
        "Каков статус утверждения «ревизия {r} использует {m}»?",
        "Можно ли по документам считать, что для ревизии {r} применяется {m}?",
    ),
    "dev": (
        "Следует ли из свидетельств, что ревизия {r} работает с материалом {m}?",
        "Что говорят источники о тезисе: ревизия {r} — материал {m}?",
        "Есть ли основания утверждать, что ревизия {r} использует {m}?",
    ),
    "holdout": (
        "Установлено ли документами применение {m} в ревизии {r}?",
        "Как оценить тезис «для ревизии {r} предусмотрен {m}»?",
        "Позволяют ли источники однозначно связать ревизию {r} с {m}?",
    ),
    "replication": (
        "Доказано ли загруженными данными, что в ревизии {r} применяется {m}?",
        "Как классифицировать утверждение о применении {m} для ревизии {r}?",
        "Можно ли принять тезис: ревизия {r} использует материал {m}?",
    ),
}
CLARIFICATION_TEMPLATES = {
    "train": (
        "Подтверждается ли применение {m} для указанной ревизии?",
        "Каков статус утверждения о материале для ревизии {r}?",
    ),
    "dev": (
        "Можно ли оценить применение {m}, если ревизия не названа?",
        "Что известно о материале ревизии {r}, если материал не указан?",
    ),
    "holdout": (
        "Как решить вопрос о {m} без обозначения ревизии?",
        "Подтверждается ли тезис для ревизии {r} без названия материала?",
    ),
    "replication": (
        "Достаточно ли данных о {m}, когда версия оборудования не указана?",
        "Как классифицировать запрос о ревизии {r} без конкретного материала?",
    ),
}
POSITIVE_TEXTS = (
    "Источник {s} указывает: для ревизии {r} применяется материал {m}.",
    "В документе {s} записано, что ревизия {r} использует {m}.",
    "{s}: утверждён материал {m} для ревизии {r}.",
)
NEGATIVE_TEXTS = (
    "Источник {s} явно отрицает применение {m} для ревизии {r}.",
    "В документе {s} сказано, что ревизия {r} не использует {m}.",
    "{s}: материал {m} не применяется в ревизии {r}.",
)


def opaque_token(namespace: str, value: str, length: int = 10) -> str:
    raw = f"{SEED}|{namespace}|{value}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:length].upper()


def entity_pairs() -> list[tuple[str, str]]:
    revisions = [f"RX-{opaque_token('revision', str(i), 8)}" for i in range(400)]
    materials = [f"MX-{opaque_token('material', str(i), 8)}" for i in range(400)]
    random.Random(SEED + 11).shuffle(revisions)
    random.Random(SEED + 29).shuffle(materials)
    return list(zip(revisions, materials))


def status_plan(split_index: int) -> list[str]:
    plan = [""] * 12
    for family in range(3):
        statuses = list(STATUSES)
        random.Random(SEED + split_index * 10 + family).shuffle(statuses)
        for block, status in enumerate(statuses):
            plan[family + block * 3] = status
    return plan
