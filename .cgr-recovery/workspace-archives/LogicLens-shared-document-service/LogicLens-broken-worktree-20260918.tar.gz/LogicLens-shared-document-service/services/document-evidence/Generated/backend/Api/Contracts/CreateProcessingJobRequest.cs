#nullable enable

using System.ComponentModel.DataAnnotations;

namespace LogicLens.DocumentEvidence.Generated.Api.Contracts;

public sealed class CreateProcessingJobRequest
{
    public Guid DocumentRevisionId { get; set; }
    [Required]
    [MaxLength(80)]
    public string Kind { get; set; } = string.Empty;
    [Required]
    [MaxLength(40)]
    public string State { get; set; } = string.Empty;
    public int Attempt { get; set; }
    public int MaxAttempts { get; set; }
    [Required]
    [MaxLength(160)]
    public string IdempotencyKey { get; set; } = string.Empty;
    public DateTime AvailableAt { get; set; }
    public Guid? LeaseToken { get; set; }
    public DateTime? LeaseUntil { get; set; }
    [MaxLength(120)]
    public string? LastErrorCode { get; set; }
    [MaxLength(2000)]
    public string? LastError { get; set; }
}
