#nullable enable

namespace LogicLens.DocumentEvidence.Generated.Api.Contracts;

public sealed class RoleLookupDto
{
    public string Value { get; set; } = string.Empty;
    public string Label { get; set; } = string.Empty;
}
